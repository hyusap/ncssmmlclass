# Report

learning_rate = 0.001

iterations = 10000

J = [ 0.4417122 , -0.40944228, -0.45519344, -0.43259493, -0.00473008]

|                 | Predicted Positive | Predicted Negative |
| --------------- | ------------------ | ------------------ |
| Actual Positive | 125                | 9                  |
| Actual Negative | 0                  | 140                |

Accuracy: 0.9671532846715328

Precision: 0.9328358208955224

Recall: 1.0

F1: 0.9652509652509652
